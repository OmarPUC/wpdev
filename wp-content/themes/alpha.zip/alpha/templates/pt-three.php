<?php

echo "<br/>PT - Three<br/>";
get_template_part("templates/pt","four");
// get_template_part("templates/pt-four");